#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HailoRT::libhailort" for configuration "Release"
set_property(TARGET HailoRT::libhailort APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HailoRT::libhailort PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhailort.so.4.23.0"
  IMPORTED_SONAME_RELEASE "libhailort.so.4.23.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS HailoRT::libhailort )
list(APPEND _IMPORT_CHECK_FILES_FOR_HailoRT::libhailort "${_IMPORT_PREFIX}/lib/libhailort.so.4.23.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
